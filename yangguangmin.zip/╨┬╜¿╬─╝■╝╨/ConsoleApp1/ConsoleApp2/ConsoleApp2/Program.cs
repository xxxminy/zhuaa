﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 0; i < 50; i++)
            {
                Console.WriteLine("第{0}行：hello cqjtu！重交物联2019级", (i + 1));
            }
            System.Console.ReadKey();
        }
    }
}
